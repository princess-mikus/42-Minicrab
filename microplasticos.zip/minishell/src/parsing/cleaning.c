/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cleaning.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcasaubo <fcasaubo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/17 11:01:48 by codespace         #+#    #+#             */
/*   Updated: 2024/06/10 14:03:15 by fcasaubo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	clean_dec(t_command *node)
{
	int		i;
	char	*temp;

	if (!node->dec || !node->dec[0])
		return ;
	i = 0;
	while (node->dec[i])
	{
		temp = ft_strtrim(node->dec[i]->name, " ");
		free(node->dec[i]->name);
		node->dec[i]->name = make_line(temp);
		i++;
	}
}

void	clean_arg(t_command *node)
{
	int		i;

	if (node->arg)
	{
		divide_arg(node);
		i = 0;
		while (node->argv[i])
		{
			node->argv[i] = make_line(node->argv[i]);
			i++;
		}
	}
	else
		node->argv = NULL;
}

void	clean_outfile(t_command *node)
{
	int		i;
	char	*temp;

	if (!node->outfile)
		return ;
	i = 0;
	while (node->outfile[i])
	{
		node->outfile[i]->special = 0;
		if (node->outfile[i]->name[1] == '>')
			node->outfile[i]->special = 1;
		temp = ft_strtrim(node->outfile[i]->name
				+ node->outfile[i]->special + 1, " ");
		free(node->outfile[i]->name);
		node->outfile[i]->name = make_line(temp);
		i++;
	}
}

void	clean_infile(t_command *node)
{
	int		i;
	char	*temp;

	if (!node->infile)
		return ;
	i = 0;
	while (node->infile[i])
	{
		node->infile[i]->special = 0;
		if (node->infile[i]->name[1] == '<')
			node->infile[i]->special = 1;
		temp = ft_strtrim(node->infile[i]->name
				+ node->infile[i]->special + 1, " ");
		free(node->infile[i]->name);
		node->infile[i]->name = make_line(temp);
		i++;
	}
}

void	cleaning(t_command *node)
{
	clean_infile(node);
	clean_outfile(node);
	if (node->command)
		node->command = make_line(node->command);
	clean_arg(node);
	clean_dec(node);
}
