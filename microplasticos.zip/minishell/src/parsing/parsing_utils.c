/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing_utils.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcasaubo <fcasaubo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 10:46:35 by fcasaubo          #+#    #+#             */
/*   Updated: 2024/06/10 14:08:09 by fcasaubo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

char	**split_out_of_q(char *str, char c)
{
	char	**splited;
	int		i;
	int		j;
	int		k;

	splited = ft_calloc(sizeof(char *), count_out_quotes(str, c) + 2);
	splited[count_out_quotes(str, c) + 1] = NULL;
	i = 0;
	j = 0;
	k = 0;
	while (str[i])
	{
		if (is_out_quotes(str, i, c))
		{
			splited[k] = ft_substr(str, j, (i - 1) - j);
			k++;
			i = i + 1;
			j = i;
		}
		else
			i++;
		if (!str[i])
			splited[k] = ft_strdup(str + j);
	}
	return (splited);
}

int	start_dec(char *line)
{
	int	i;

	i = search_out_quotes(line, '=') - line;
	while (i > 0 && line[i] != ' ')
		i--;
	if (i > 0)
		i++;
	return (i);
}

t_file	**make_files(char *line, char c)
{
	t_file	**vector;
	int		n;

	if (count_out_quotes(line, c) != 0)
	{
		n = c_out_q_no_d(line, c);
		if (c == '=')
			n = count_out_quotes(line, c);
		vector = malloc(sizeof(t_file *) * (n + 1));
		vector[n] = NULL;
		while (n > 0)
			vector[--n] = malloc(sizeof(t_file));
	}
	else
		vector = NULL;
	return (vector);
}

int	logic(char *temp, char caso, char other)
{
	if (search_out_quotes(temp, caso))
	{
		if (search_out_quotes(temp, other)
			&& (search_out_quotes(temp, other)
				< search_out_quotes(temp, caso)))
			return (false);
		return (true);
	}
	return (false);
}
