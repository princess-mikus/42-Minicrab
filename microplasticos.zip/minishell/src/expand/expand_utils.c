/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   expand_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcasaubo <fcasaubo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/10 13:57:45 by fcasaubo          #+#    #+#             */
/*   Updated: 2024/06/10 13:58:34 by fcasaubo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

bool	is_betwen_s_quotes(char *line, int i)
{
	int	j;
	int	status_1;
	int	status_2;

	j = 0;
	status_1 = 0;
	status_2 = 0;
	while (line[j])
	{
		if (line[j] == '\"' && status_2 % 2 == 0)
			status_1++;
		if (line[j] == '\'' && status_1 % 2 == 0)
			status_2++;
		if (j == i && status_2 % 2 != 0)
			return (false);
		j++;
	}
	return (true);
}

bool	is_betwen_quotes(char *line, int i)
{
	int	j;
	int	status_1;
	int	status_2;

	j = 0;
	status_1 = 0;
	status_2 = 0;
	while (line[j])
	{
		if (line[j] == '\"' && status_2 % 2 == 0)
			status_1++;
		if (line[j] == '\'' && status_1 % 2 == 0)
			status_2++;
		if (j == i && (status_2 % 2 || status_1 % 2) != 0)
			return (false);
		j++;
	}
	return (true);
}

int	normal_len(int *i, t_envp **envp_mx, char *input)
{
	int		len;
	int		start;
	char	*temp;

	len = 0;
	start = *i + 1;
	*i += 1;
	while (input[*i] && input[*i] != ' ' && input[*i] != '$'
		&& input[*i] != '"' && input[*i] != '\'')
	{
		len++;
		*i += 1;
	}
	*i -= 1;
	temp = ft_substr(input, start, len);
	if (get_content_envp_mx(envp_mx, temp))
		len = ft_strlen(get_content_envp_mx(envp_mx, temp));
	free(temp);
	return (len - 1);
}

int	home_len(int *i, t_envp **envp_mx, char *input)
{
	int		len;

	len = 0;
	*i += 1;
	while (input[*i] && input[*i] != ' ' && input[*i] != '$'
		&& input[*i] != '"' && input[*i] != '\'')
	{
		len++;
		*i += 1;
	}
	*i -= 1;
	len = ft_strlen(get_content_envp_mx(envp_mx, "~"));
	return (len - 1);
}

int	line_len(t_envp **envp_mx, char *input)
{
	int		len;
	int		i;

	i = 0;
	len = 0;
	while (input[i])
	{
		if (input[i] == '$' && is_betwen_s_quotes(input, i))
			len += normal_len(&i, envp_mx, input);
		else if (input[i] == '~')
			len += home_len(&i, envp_mx, input);
		len++;
		i++;
	}
	return (len);
}
