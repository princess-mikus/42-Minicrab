/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcasaubo <fcasaubo@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/05/16 21:05:30 by mikus             #+#    #+#             */
/*   Updated: 2024/06/10 14:07:28 by fcasaubo         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# include "libft.h"
# include "structures.h"
# include <stdio.h>
# include <stdbool.h>
# include <wait.h>
# include <sys/stat.h>
# include <signal.h>
# include <errno.h>
# include <readline/readline.h>
# include <readline/history.h>

void		add_var_to_envp_mx(t_envp **envp_mx, char *variable, char *content);
void		init_envp(t_envp **envp_mx, char **envp);
void		envp_add_back(t_envp **envp_mx, t_envp *new);
t_envp		*new_envp(char *variable, char *content);
int			is_envp(t_envp **envp_mx, char *variable);
char		*get_content_envp_mx(t_envp **envp_mx, char *variable);
void		free_envp_mx(t_envp **envp_mx);
char		**envp_mx_to_arg(t_envp **envp_mx);
t_envp		*get_node_envp_mx(t_envp **envp_mx, char *variable);
void		unset_mx(t_envp **envp_mx, char *variable);
void		env_mx(t_envp **envp_mx);
int			export_mx(t_envp **envp_mx, char **argv, t_file **dec);
int			pwd_mx(void	);
int			cd_mx(t_envp **envp_mx, char **args);
int			echo_mx(char **arguments);
void		parse(char *line_expanded, t_command **commands);
void		init_node(t_command *node, char *line);
t_command	*new_command(char *line);
void		add_command(char *line_splited, t_command **commands);
char		*get_infile(char *line, char **infile);
char		*get_outfile(char *line, char **outfile);
int			start_dec(char *line);
char		*get_dec(char *line, t_command *node);
char		*get_cmd(char *line, t_command *node);
void		get_arg(char *line, t_command *node);
void		cleaning(t_command *node);
char		*make_line(char *str);
char		*expansion(t_envp **envp_mx, char *input);
bool		check_integrity(char *line);
void		parse_commands(char *line, t_envp **envp_mx);
void		wait_for_children(t_command *current);
int			execute_commands(t_command **commands, t_envp **envp_mx);
bool		resolve_files(\
t_command *current, int *inpipe, int *outpipe, t_envp **envp_mx);
bool		check_infile_error(char *file, bool *infile);
bool		check_outfile_error(char *file, bool *outfile);
int			manage_here_doc(char **delimiter);
char		**update_environment(t_command *current, t_envp **envp_mx);
void		dec_to_env(t_file **dec, t_envp **envp_mx_temp);
void		execute_builtin(\
t_command *current, int *inpipe, int *outpipe, t_envp **envp_mx);
bool		get_builtin(char *program);
char		**get_path_var(char **envp);
bool		resolve_path(t_command *current, char **path);
void		signal_management(void);
void		kill_yourself(int sig);
void		signal_sender(t_command *command);
void		free_array(void **array);
void		free_command_list(t_command **list);
void		mx_error(char const *target);
void		resolve_exec_error(int *inpipe, int *outpipe, char *program);
int			quote_case(char *line);
char		*jmp_spaces(char *str);
int			count_out_quotes(char *line, char c);
int			c_out_q_no_d(char *line, char c);
char		*search_out_quotes(char *line, char c);
char		*search_out_quotes(char *line, char c);
char		*line_cutter(char *line, char *to_cut);
bool		is_out_quotes(char *line, int k, char c);
bool		is_betwen_s_quotes(char *line, int i);
bool		is_betwen_quotes(char *line, int i);
int			normal_len(int *i, t_envp **envp_mx, char *input);
int			home_len(int *i, t_envp **envp_mx, char *input);
int			line_len(t_envp **envp_mx, char *input);
void		divide_arg(t_command *node);
int			get_arg_end(char *line, char c);
int			quote_case(char *line);
char		**split_out_of_q(char *str, char c);
int			start_dec(char *line);
t_file		**make_files(char *line, char c);
int			logic(char *temp, char caso, char other);
#endif
